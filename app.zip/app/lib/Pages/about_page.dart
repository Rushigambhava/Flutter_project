import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AboutUsPage extends StatelessWidget {
  const AboutUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("About Us"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: const [
                  Icon(Icons.keyboard, size: 64, color: Colors.purple),
                  SizedBox(height: 8),
                  Text(
                    "Typing Tutor",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            buildSectionTitle("Meet Our Team"),
            buildCard(const [
              "Developed by: Rushi Gambhava (23010101082)",
              "Mentored by: Prof. Mehul Bhundiya (Computer Engineering Department), School of Computer Science",
              "Explored by: ASWDC, School of Computer Science",
              "Eulogized by: Darshan University, Rajkot, Gujarat - INDIA",
            ]),
            const SizedBox(height: 24),
            buildSectionTitle("About ASWDC"),
            buildCard(const [
              "ASWDC is Application, Software and Website Development Center @ Darshan University run by Students and Staff of School of Computer Science.",
              "Sole purpose of ASWDC is to bridge gap between university curriculum & industry demands. Students learn cutting-edge technologies, develop real-world application & experience professional environment @ ASWDC under guidance of industry experts & faculty members.",
            ]),
            const SizedBox(height: 24),
            buildSectionTitle("Contact Us"),
            buildCard(const [
              "Email: aswdc@darshan.ac.in",
              "Phone: +91-9727747317",
              "Website: www.darshan.ac.in",
            ]),
            const SizedBox(height: 24),
            const Center(
              child: Text(
                "© 2025 Darshan University\nAll Rights Reserved - Privacy Policy\nMade with ❤️ in India",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: Colors.purple,
      ),
    );
  }

  Widget buildCard(List<String> content) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: content.map((text) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Text(
              text,
              style: const TextStyle(fontSize: 14),
            ),
          )).toList(),
        ),
      ),
    );
  }
}

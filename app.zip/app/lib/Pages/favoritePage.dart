import 'package:app/Pages/user_Detail.dart';
import 'package:app/Pages/user_list.dart';
import 'package:flutter/material.dart';
import 'add_user.dart';
import 'userData.dart';

final User myUser = User.instance;

class FavoriteUsersPage extends StatefulWidget {
  @override
  _FavoriteUsersPageState createState() => _FavoriteUsersPageState();
}

class _FavoriteUsersPageState extends State<FavoriteUsersPage> {
  @override
  Widget build(BuildContext context) {
    final favoriteUsers = myUser.getFavoriteUsers();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Favorite Users"),
        backgroundColor: Colors.redAccent.shade100,
      ),
      body: favoriteUsers.isEmpty
          ? const Center(
              child: Text(
                "No favorite users yet!",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            )
          : ListView.builder(
              itemCount: favoriteUsers.length,
              itemBuilder: (context, index) {
                final user = favoriteUsers[index];
                return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: GestureDetector(
                        onTap: () async {
                          int correctIndex = myUser.getUserList().indexWhere((u) => u['id'] == user['id']);
                          if (correctIndex == -1) return;
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  DetailedUser(index: correctIndex),
                            ),
                          ).then(
                                (value) {
                              users = myUser.getUserList();
                            },
                          );
                        },
                        child: Card(
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "${user['fullName']}",
                                          style: const TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text("City: ${user['city']}"),
                                        Text("Email: ${user['email']}"),
                                        Text("Mobile: ${user['number']}"),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.edit,
                                            color: Colors.blue),
                                        onPressed: () async {
                                          final result = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => AddUserForm(
                                                  userData: user, index: index),
                                            ),
                                          );
                                          if (result == true) {
                                            setState(() {
                                              users = myUser.getUserList();
                                            });
                                          }
                                        },
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete,
                                            color: Colors.red),
                                        onPressed: () {
                                          showDialog(
                                              context: context,
                                              builder: (context) => AlertDialog(
                                                    title: Text(
                                                        'Are you sure want to delete.'),
                                                    actions: [
                                                      TextButton(
                                                        onPressed: () {
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        child: Text('Cancel'),
                                                      ),
                                                      TextButton(
                                                        onPressed: () {
                                                          setState(() {
                                                            myUser.deleteUser(
                                                                index);
                                                          });
                                                          Navigator.pop(
                                                              context);
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                            const SnackBar(
                                                              content: Text(
                                                                  'User deleted successfully'),
                                                              duration:
                                                                  Duration(
                                                                      seconds:
                                                                          3),
                                                            ),
                                                          );
                                                        },
                                                        child: Text('Delete'),
                                                      ),
                                                    ],
                                                  ));
                                        },
                                      ),
                                      IconButton(
                                        icon: Icon(
                                          Icons.favorite_rounded,
                                          color: user['isLiked']
                                              ? Colors.red[900]
                                              : Colors.grey,
                                        ),
                                        onPressed: () {
                                          setState(() {
                                            myUser.toggleFavorite(index);
                                          });

                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(
                                            SnackBar(
                                              content: Text(user['isLiked']
                                                  ? 'Added to favorites'
                                                  : 'Removed from favorites'),
                                              duration: const Duration(
                                                  milliseconds: 500),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ]),
                          ),
                        )));
              },
            ),
    );
  }
}

class User {
  List<Map<String, dynamic>> userList = [];

  List<Map<String, dynamic>> favoriteUsers = [];

  User._privateConstructor() {
    addUserInList(
        fullName: 'Bob',
        email: 'bob.williams@example.com',
        number: '2233445566',
        dob: '04/04/1980',
        city: 'Surat',
        gender: 1,
        hobbies: ['Cooking'],
        password: 'password101',
        confirmPassword: 'password101');
    addUserInList(
        fullName: 'Charlie',
        email: 'charlie.brown@example.com',
        number: '3344556677',
        dob: '11/11/1995',
        city: 'Morbi',
        gender: 1,
        hobbies: ['Gaming'],
        password: 'password202',
        confirmPassword: 'password202');
  }

  static final User instance = User._privateConstructor();

  void toggleFavorite(int index) {
    userList[index]['isLiked'] = !userList[index]['isLiked'];

    if (userList[index]['isLiked']) {
      favoriteUsers.add(userList[index]);
    } else {
      favoriteUsers.removeWhere((user) => user['email'] == userList[index]['email']);
    }
  }

  List<Map<String, dynamic>> getFavoriteUsers() {
    return favoriteUsers;
  }

  void addUserInList(
      {required fullName,
      required email,
      required number,
      required dob,
      required city,
      required gender,
      required hobbies,
      required password,
      required confirmPassword}) {
    Map<String, dynamic> map = {};
    map['fullName'] = fullName;
    map['email'] = email;
    map['number'] = number;
    map['dob'] = dob;
    map['age'] = calculateAge(dob);
    map['city'] = city;
    map['gender'] = gender;
    map['hobbies'] = hobbies;
    map['password'] = password;
    map['confirmPassword'] = confirmPassword;
    map['isLiked'] = false;
    userList.add(map);
  }

  List<Map<String, dynamic>> getUserList() {
    return userList;
  }

  void updateUser(
      {required fullName,
      required email,
      required number,
      required dob,
      required city,
      required gender,
      required hobbies,
      required password,
      required confirmPassword,
      required id}) {
    Map<String, dynamic> map = {};
    map['fullName'] = fullName;
    map['email'] = email;
    map['number'] = number;
    map['dob'] = dob;
    map['age'] = calculateAge(dob); // Recalculate age based on the new DOB
    map['city'] = city;
    map['gender'] = gender;
    map['hobbies'] = hobbies;
    map['password'] = password;
    map['confirmPassword'] = confirmPassword;
    map['isLiked'] = userList[id]['isLiked'];
    userList[id] = map;
  }

  void deleteUser(id) {
    userList.removeAt(id);
    favoriteUsers.removeAt(id);

  }

  List<Map<String, dynamic>>? searchDeatail({required searchData}) {
    List<Map<String, dynamic>> temp = [];
    for (var element in userList) {
      String name =
          '${element['fullName'].toString().toLowerCase()} ${element['lastName'].toString().toLowerCase()}';
      if (searchData != ' ' &&
          (name.contains(searchData.toString().toLowerCase()) ||
              element['city']
                  .toString()
                  .toLowerCase()
                  .contains(searchData.toString().toLowerCase()) ||
              element['number']
                  .toString()
                  .toLowerCase()
                  .contains(searchData.toString().toLowerCase()) ||
              element['age']
                  .toString()
                  .toLowerCase()
                  .contains(searchData.toString().toLowerCase()) ||
              element['email']
                  .toString()
                  .toLowerCase()
                  .contains(searchData.toString().toLowerCase()))) {
        temp.add(element);
      }
    }
    return temp;
  }

  int calculateAge(String dateOfBirth) {
    DateTime birthDate =
        DateTime.parse(dateOfBirth.split('/').reversed.join('-'));
    DateTime today = DateTime.now();
    int age = today.year - birthDate.year;
    if (today.month < birthDate.month ||
        (today.month == birthDate.month && today.day < birthDate.day)) {
      age--;
    }
    return age;
  }
}

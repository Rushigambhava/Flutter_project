// import 'package:flutter/cupertino.dart';
//
// class Deleteuser extends StatefulWidget {
//   const Deleteuser({super.key});
//
//   @override
//   State<Deleteuser> createState() => _DeleteuserState();
// }
//
// class _DeleteuserState extends State<Deleteuser> {
//
//   @override
//   Widget build(BuildContext context) {
//     return ;
//   }
// }

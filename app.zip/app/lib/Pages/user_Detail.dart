import 'package:flutter/material.dart';
import 'userData.dart';
import 'add_user.dart';

final User myUser = User.instance;

class DetailedUser extends StatefulWidget {
  final int index;
  const DetailedUser({super.key, required this.index});

  @override
  State<DetailedUser> createState() => _DetailedUserState();
}

class _DetailedUserState extends State<DetailedUser> {
  @override
  Widget build(BuildContext context) {
    final user = myUser.getUserList()[widget.index];
    final String imageUrl = 'assets/images/default-avatar-profile-icon-of-social-media-user-vector.jpg';

    Widget buildKeyValueRow(String key, String value) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Text(
                key,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black87),
              ),
            ),
            Text(
              ':',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black54),
            ),
            SizedBox(width: 8),
            Expanded(
              flex: 5,
              child: Text(
                value,
                style: TextStyle(fontSize: 18, color: Colors.black54),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("${user['fullName']}"),
        backgroundColor: Colors.redAccent.shade100,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    CircleAvatar(
                      backgroundImage: AssetImage(imageUrl),
                      radius: 50,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "${user['fullName']}",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black87),
                    ),
                    SizedBox(height: 10),
                    Divider(),
                    SizedBox(height: 10),
                    buildKeyValueRow("Gender", user['gender'] == 0 ? 'Female' : 'Male'),
                    buildKeyValueRow("Date of Birth", user['dob']),
                    buildKeyValueRow("Age", user['age'].toString()),
                    buildKeyValueRow("City", user['city'].toString()),
                    buildKeyValueRow("Hobbies", user['hobbies'].join(', ')),
                    SizedBox(height: 20),
                    Text(
                      "Contact Details",
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
                    ),
                    buildKeyValueRow("Email ID", user['email']),
                    buildKeyValueRow("Phone", user['number'].toString()),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton.icon(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddUserForm(userData: user, index: widget.index),
                      ),
                    );
                    if (result == true) {
                      setState(() {});
                    }
                  },
                  icon: Icon(Icons.edit, color: Colors.white),
                  label: Text("Edit"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Delete User'),
                        content: Text('Are you sure you want to delete this user?'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('Cancel'),
                          ),
                          TextButton(
                            onPressed: () {
                              setState(() {
                                myUser.deleteUser(widget.index);
                              });
                              Navigator.pop(context, true);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('User deleted successfully!'),
                                  backgroundColor: Colors.red,
                                  duration: Duration(seconds: 2),
                                ),
                              );
                              Navigator.pop(context, true);
                            },
                            child: Text('Delete', style: TextStyle(color: Colors.red)),
                          ),
                        ],
                      ),
                    );
                  },
                  icon: Icon(Icons.delete, color: Colors.white),
                  label: Text("Delete"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      user['isLiked'] = !user['isLiked'];
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(user['isLiked'] ? 'User liked!' : 'User unliked!'),
                        duration: Duration(milliseconds: 800),
                      ),
                    );
                  },
                  icon: Icon(
                    Icons.favorite_rounded,
                    color: user['isLiked'] ? Colors.red : Colors.white,
                  ),
                  label: Text(user['isLiked'] ? "Unlike" : "Like"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: user['isLiked'] ? Colors.pink : Colors.grey,
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

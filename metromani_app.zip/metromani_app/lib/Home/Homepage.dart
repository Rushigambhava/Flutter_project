import 'package:flutter/material.dart';

void main() {
  runApp(MatrimonialApp());
}

class MatrimonialApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Matrimonial"),
        backgroundColor: Colors.teal,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.teal,
              ),
              child: Text(
                'Matrimonial Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.person_add),
              title: Text('Add User'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddUserScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.list_alt),
              title: Text('User List'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.favorite),
              title: Text('Favorites'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => FavoritesScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.info),
              title: Text('About Us'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AboutUsScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildCard(context, "Add User", Icons.person_add, Colors.tealAccent, AddUserScreen()),
            SizedBox(height: 16),
            _buildCard(context, "User List", Icons.list_alt, Colors.amberAccent, UserListScreen()),
            SizedBox(height: 16),
            _buildCard(context, "Favorites", Icons.favorite, Colors.pinkAccent, FavoritesScreen()),
            SizedBox(height: 16),
            _buildCard(context, "About Us", Icons.info, Colors.blueAccent, AboutUsScreen()),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, String title, IconData icon, Color color, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => screen),
        );
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 30, color: Colors.white),
              SizedBox(width: 10),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AddUserScreen extends StatefulWidget {
  final User? user;
  final int? index;

  AddUserScreen({this.user, this.index});

  @override
  _AddUserScreenState createState() => _AddUserScreenState();
}

class _AddUserScreenState extends State<AddUserScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _cityController = TextEditingController();
  final _dobController = TextEditingController();
  String? _selectedGender;
  bool _isReading = false;
  bool _isMusic = false;
  bool _isTraveling = false;

  @override
  void initState() {
    super.initState();
    if (widget.user != null) {
      _nameController.text = widget.user!.name;
      _emailController.text = widget.user!.email;
      _mobileController.text = widget.user!.mobile;
      _cityController.text = widget.user!.city;
      _dobController.text = widget.user!.dob;
      _selectedGender = widget.user!.gender;
      List<String> hobbies = widget.user!.hobbies.split(", ");
      _isReading = hobbies.contains("Reading");
      _isMusic = hobbies.contains("Music");
      _isTraveling = hobbies.contains("Traveling");
    }
  }

  void _saveUser() {
    if (_formKey.currentState!.validate()) {
      final newUser = User(
        name: _nameController.text,
        email: _emailController.text,
        mobile: _mobileController.text,
        city: _cityController.text,
        dob: _dobController.text,
        gender: _selectedGender ?? "Not specified",
        age: calculateAge(_dobController.text),
        hobbies: [
          if (_isReading) "Reading",
          if (_isMusic) "Music",
          if (_isTraveling) "Traveling",
        ].join(", "),
      );

      if (widget.index != null) {
        UserListScreen.users[widget.index!] = newUser;
      } else {
        UserListScreen.users.add(newUser);
      }

      Navigator.pop(context);
    }
  }

  int calculateAge(String dob) {
    try {
      DateTime birthDate = DateTime.parse(dob);
      DateTime today = DateTime.now();
      int age = today.year - birthDate.year;
      if (today.month < birthDate.month ||
          (today.month == birthDate.month && today.day < birthDate.day)) {
        age--;
      }
      return age;
    } catch (e) {
      return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.user == null ? "Add User" : "Edit User"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: "Name",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value!.isEmpty ? "Enter name" : null,
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: "Email",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value!.isEmpty ? "Enter email" : null,
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _mobileController,
                  decoration: InputDecoration(
                    labelText: "Mobile",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value!.isEmpty ? "Enter mobile number" : null,
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _cityController,
                  decoration: InputDecoration(
                    labelText: "City",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _dobController,
                  decoration: InputDecoration(
                    labelText: "Date of Birth (YYYY-MM-DD)",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value!.isEmpty ? "Enter date of birth" : null,
                ),
                SizedBox(height: 16),
                Row(
                  children: [
                    Text("Gender: "),
                    SizedBox(width: 16),
                    Expanded(
                      child: RadioListTile(
                        title: Text("Male"),
                        value: "Male",
                        groupValue: _selectedGender,
                        onChanged: (value) {
                          setState(() {
                            _selectedGender = value.toString();
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: RadioListTile(
                        title: Text("Female"),
                        value: "Female",
                        groupValue: _selectedGender,
                        onChanged: (value) {
                          setState(() {
                            _selectedGender = value.toString();
                          });
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Text("Hobbies:"),
                CheckboxListTile(
                  title: Text("Reading"),
                  value: _isReading,
                  onChanged: (value) {
                    setState(() {
                      _isReading = value!;
                    });
                  },
                ),
                CheckboxListTile(
                  title: Text("Music"),
                  value: _isMusic,
                  onChanged: (value) {
                    setState(() {
                      _isMusic = value!;
                    });
                  },
                ),
                CheckboxListTile(
                  title: Text("Traveling"),
                  value: _isTraveling,
                  onChanged: (value) {
                    setState(() {
                      _isTraveling = value!;
                    });
                  },
                ),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: _saveUser,
                      child: Text("Save"),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _formKey.currentState!.reset();
                          _selectedGender = null;
                          _isReading = false;
                          _isMusic = false;
                          _isTraveling = false;
                        });
                      },
                      child: Text("Reset"),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class UserListScreen extends StatefulWidget {
  static final List<User> users = [];
  static final List<User> favoriteUsers = [];

  @override
  _UserListScreenState createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("User List"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: UserListScreen.users.isEmpty
            ? Center(
          child: Text(
            "No users added yet",
            style: TextStyle(fontSize: 18, color: Colors.grey),
          ),
        )
            : ListView.builder(
          itemCount: UserListScreen.users.length,
          itemBuilder: (context, index) {
            final user = UserListScreen.users[index];
            final isFavorite = UserListScreen.favoriteUsers.contains(user);
            return Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          user.name,
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(
                                isFavorite ? Icons.favorite : Icons.favorite_border,
                                color: Colors.pink,
                              ),
                              onPressed: () {
                                setState(() {
                                  if (isFavorite) {
                                    UserListScreen.favoriteUsers.remove(user);
                                  } else {
                                    UserListScreen.favoriteUsers.add(user);
                                  }
                                });
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.edit, color: Colors.blue),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => AddUserScreen(user: user, index: index),
                                  ),
                                ).then((_) => setState(() {}));
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                setState(() {
                                  UserListScreen.favoriteUsers.remove(user);
                                  UserListScreen.users.remove(user);
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                    Text("City: ${user.city}"),
                    Text("Email: ${user.email}"),
                    Text("Mobile: ${user.mobile}"),
                    Text("Date of Birth: ${user.dob}"),
                    Text("Gender: ${user.gender}"),
                    Text("Age: ${user.age}"),
                    Text("Hobbies: ${user.hobbies}"),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class FavoritesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Favorites"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: UserListScreen.favoriteUsers.isEmpty
            ? Center(
          child: Text(
            "No favorite users yet",
            style: TextStyle(fontSize: 18, color: Colors.grey),
          ),
        )
            : ListView.builder(
          itemCount: UserListScreen.favoriteUsers.length,
          itemBuilder: (context, index) {
            final user = UserListScreen.favoriteUsers[index];
            return Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.name,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Text("City: ${user.city}"),
                    Text("Email: ${user.email}"),
                    Text("Mobile: ${user.mobile}"),
                    Text("Date of Birth: ${user.dob}"),
                    Text("Gender: ${user.gender}"),
                    Text("Age: ${user.age}"),
                    Text("Hobbies: ${user.hobbies}"),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class User {
  final String name;
  final String email;
  final String mobile;
  final String city;
  final String dob;
  final String gender;
  final int age;
  final String hobbies;

  User({
    required this.name,
    required this.email,
    required this.mobile,
    required this.city,
    required this.dob,
    required this.gender,
    required this.age,
    required this.hobbies,
  });
}

class AboutUsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("About Us"),
        backgroundColor: Colors.teal,
      ),
      body: Center(
        child: Text("About Us Screen"),
      ),
    );
  }
}